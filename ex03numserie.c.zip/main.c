#include <stdio.h>

int main(void) {
printf("3.041839");

  return 0;
}