#include <stdio.h>

int main(void) {
  int segundos, hr, min, sg;
    printf( "ingrese sus segundos" );
      scanf ("%i", &segundos );
    
    hr = (segundos/3600);
    min = (segundos -(hr*3600))/60;
    sg = segundos -(hr*3600+min*60);


  printf ( "Horas: %i\nMinutos: %i\nSegundos: %i\n", hr, min, sg );

  return 0;
}