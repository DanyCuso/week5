#include <stdio.h>

int main(void) {
 int n;

 printf("escriba el año deseado:");
  scanf("%i", &n);

if (n %4 == 0 && n %100 == 0 && n %400 == 0){
    printf("El año es bisiesto");

}
else
  printf("El año no es bisiesto");
  return 0;
}