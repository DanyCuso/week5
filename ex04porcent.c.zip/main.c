#include <stdio.h>

int main(void) {
  float a, b, c, t, A, B, C;
    printf("incerte cantidad inveritida #1:");
      scanf("%f", &a);
    printf("incerte cantidad invertida #2:");
      scanf("%f", &b);
    printf("incerte cantidad invertida #3:");
      scanf("%f", &c);

    t = (a + b + c);

    A = ((a*100)/t);
    B = ((b*100)/t);
    C = ((c*100)/t);

    printf("la inversion por persona es igual a\ninversor 1: %f\nInversor 2: %f\nInversor 3: %f", A, B, C );


  return 0;
}